﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Xenon.WPF.Common.Weather
{
    public class WeatherWind
    {
        public string speed { get; set; }
        public string deg { get; set; }
    }
}
