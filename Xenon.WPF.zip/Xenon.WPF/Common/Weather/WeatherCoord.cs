﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Xenon.WPF.Common.Weather
{
    public class WeatherCoord
    {
        public string lon { get; set; }
        public string lat { get; set; }
    }
}
